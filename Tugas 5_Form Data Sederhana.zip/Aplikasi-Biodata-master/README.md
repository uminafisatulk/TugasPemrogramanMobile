# Aplikasi-Biodata
Source Code Aplikasi Biodata

# Tutorial Build with Android Studio
https://youtu.be/fVLOWBOQeRc

# Tutorial Build with Step by Step
https://rivaldi48.blogspot.com/2019/04/tutorial-membuat-aplikasi-biodata.html
